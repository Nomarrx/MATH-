/**
 *  Class with main method for testing functions implementing ACFunction<br>
 *
 * @author     MATH 282
 * @created    August 30, 2017
 */

public class TestFunction
{
    /**
     *  The main program for the TestFunction class<br>
     *
     * @param  args  the command line arguments
     */
    public static void main(String[] args)
    {
        IFunction f1 = new Function1();  // instantiate specific function
        System.out.println( "Table of function 1, f(x) = 2x + 1" );
        f1.printTable( -1.0, 2.0, 1.0 );  // test function by printing values

        IFunction f2 = new Function2();
        System.out.println( "Table of function 2, f(x) = 21 x^2 - 38 x - 15" );
        f2.printTable( -2.0, 3.0, 1.0 );
        f2.printTable( -2.5, 3.5, 0.5 );
    }
}
