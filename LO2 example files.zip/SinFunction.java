/*
 *  Date submitted:  September 19, 2018
 *  Assignment number:  N/A
 *  Course name:  MATH 282
 *  Instructor:  Michael Grzesina
 */

/**
 *  Purpose: Use an iterative method to calculate the sine of an angle x, where
 *  the angle x is expressed in radians (note that radians = degrees * PI / 180
 *  since radians are the number of radiuses of the circle for that angle)
 *
 * @author Michael Grzesina (cst000)
 * @version 1.0
 */
public class SinFunction
{
    /**
     * Purpose: Main method used for testing our sine function vs. the built-in
     *          Math.sin() function for a given angle and desired precision 
     * @param args  Not used
     */
    public static void main( String[] args )
    {
        // Given an angle x in radians and a desired precision to achieve:
        double angle = 30.0 * Math.PI / 180.0;  // radians = degrees * PI / 180
            // Try angle of 30 degrees - answer should be 0.5
            // Try angle of 45 degrees - answer should be approximately 0.7071
            // Try angle of 90 degrees - answer should be 1.0
            // Try angle of 16 * 180 degrees - answer should be 0
        double precision = 0.000001;
        
        // Display the results
        System.out.println(myNaiveSin(angle, precision) +
                " is the result of our iterative method (simple formula)");
        System.out.println(mySin(angle, precision) +
                " is the result of our iterative method (efficient formula)");
        System.out.println(Math.sin(angle) +
                " is the result of Java's Math.sin() method");
    }

    
    /**
     * Purpose: Calculate sine of an angle x to within a desired precision
     *          using an iterative method (simple formula)
     * @param x             angle to find the sine of (in radians)
     * @param dPrecision    desired precision for our answer
     * @return              sin(x) to within the desired precision
     */
    public static double myNaiveSin(double x, double dPrecision)
    {
        double term = x; // first term of formula is x^1 / 1! = x / 1 = x
        double result = term; // initial approximation is first term
        int i = 0; // number of the term of the formula
        double sign = 1.0; // + or - sign for the term
        
        // while result is not "close enough" using relative error
        while (result != 0.0 && Math.abs(term / result) > dPrecision)
        {
            // calculate a better approximation
            // using next term of the infinite series x/1! - x^3/3! + x^5/5!...
            i++;
            sign *= -1.0;
            term = sign * Math.pow(x, 2.0 * i + 1.0) / dFact(2 * i + 1);
            result += term;
        }
        
        return result; // return the last approximation
    }


    /**
     * Purpose: Calculate sine of an angle x to within a desired precision
     *          using an iterative method (efficient formula)
     * @param x             angle to find the sine of (in radians)
     * @param dPrecision    desired precision for our answer
     * @return              sin(x) to within the desired precision
     */
    public static double mySin(double x, double dPrecision)
    {
        x = x % (2.0 * Math.PI); // make angle between 0 and 360 degrees
            // to avoid problems with roundoff error for bigger angles
        
        double term = x; // first term of formula is x^1 / 1! = x / 1 = x
        double result = term; // initial approximation is first term
        int i = 0; // number of the term of the formula
        
        // while result is not "close enough" using relative error
        while (result != 0.0 && Math.abs(term / result) > dPrecision)
        {
            // calculate a better approximation
            // using next term of the infinite series x/1! - x^3/3! + x^5/5!...
            i++;
            term *= -1.0 * x * x / (2.0 * i * (2.0 * i + 1.0));
            result += term;
        }
        
        return result; // return the last approximation
    }

    
    /**
     * Purpose: Calculates n! = n * (n-1) * (n-2) * ... * 3 * 2 * 1
     * Using an double data type, it is only completely accurate (no
     * rounding) up to ???, and it is only correct with rounding up to ???
     * 
     * @param n Number for which the factorial is to be calculated
     * @return  The factorial n! of the given number
     */
    public static double dFact( int n )
    {
        double result = 1.0;
     
        for (int i = 2; i <= n; i++)
        {
            result *= i;
        }
        
        return result;
    }
}
