/*
 *  Date submitted: September 2017
 *  Assignment number: N/A
 *  Course name:  MATH 282
 *  Instructor:  Michael Grzesina
 */

/**
 *  Purpose: Demonstrate iterative methods for calculating values
 *
 * @author MATH 282
 * @version 1.0
 */

public class IterativeMethodsExamples
{
    /**
     * Purpose: Run various tests of iterative methods
     * 
     * @param args  Command-line arguments (not used)
     */
    public static void main( String[] args )
    {
        System.out.println( "Test exponential function:" );
        System.out.println( "e^850 = " + myExponentialFunction(850.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(650.0) );
        System.out.println( "e^650 = " + myExponentialFunction(850.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(650.0) );
        System.out.println( "e^87.5 = " + myExponentialFunction(87.5, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(87.5) );
        System.out.println( "e^-20 = " + myExponentialFunction(-20.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(-20.0) );
        System.out.println( "e^-40 = " + myExponentialFunction(-40.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(-40.0) );
        System.out.println( "e^-15 = " + myExponentialFunction(-15.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(-15.0) );
            
        System.out.println( "\nTest improved exponential function:" );
        System.out.println( "e^850 = " + myImprovedExp(850.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(850.0) );
        System.out.println( "e^650 = " + myImprovedExp(650.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(650.0) );
        System.out.println( "e^87.5 = " + myImprovedExp(87.5, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(87.5) );
        System.out.println( "e^-20 = " + myImprovedExp(-20.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(-20.0) );
        System.out.println( "e^-40 = " + myImprovedExp(-40.0, 0.0000001) + " vs. Math.exp value:" );
        System.out.println( Math.exp(-40.0) );
        System.out.println( "e^-15 = " + myImprovedExp(-15.0, 0.0000001)  + " vs. Math.exp value:");
        System.out.println( Math.exp(-15.0) );
            
        System.out.println( "\nTest sine function:" );
        System.out.println( mySin( Math.PI / 4.0, 0.000001 ) ); // 45 degrees
        System.out.println( Math.sin( Math.PI / 4.0 ) );
        System.out.println( mySin( Math.PI / 2.0, 0.000001 ) ); // 90 degrees
        System.out.println( Math.sin( Math.PI / 2.0 ) );
        System.out.println( mySin( Math.PI, 0.000001 ) ); // 180 degrees
        System.out.println( Math.sin( Math.PI ) );
        System.out.println( mySin( 220.25 * Math.PI, 0.000001 ) ); // 45 degrees
        System.out.println( Math.sin( 220.25 * Math.PI ) );
 
        System.out.println( "\nSquare root test:" );
        System.out.println( mySqrt( 2.0, 0.000001 ) );
        System.out.println( mySqrt( 9.0, 0.000001 ) );
        System.out.println( mySqrt( 16.0, 0.000001 ) );
    }

    
    /**
     * Purpose: Calculate e^x (where e is the special number that is the base of
     * the natural logarithms) using power series x^0/0! + x^1/1! + ...
     * This is a straightforward (dumb) implementation
     * 
     * @param dValue        value to find e^value
     * @param dPrecision    desired level of precision for calculation
     * @return              e^value to within the desired precision
     */
    public static double myExponentialFunction( double dValue, double dPrecision )
    {
        double dResult = 0.0; // initial approximation
        double dOldResult = 0.0;
        int iCount = 0;
        
        do {
            dOldResult = dResult;
            // add x^i / i! for better approximation
            dResult += Math.pow( dValue, iCount ) / fact( iCount ); 
            iCount++;
        } while ( Math.abs(dResult - dOldResult) > dPrecision ); // "close enough"
        
        return dResult; // last approximation
    }
    
    
    /**
     * Purpose: Calculate n! (helper method for myExponentialFunction)
     * 
     * @param n Number to calculate factorial of
     * @return  n! = n * (n-1) * (n-2) * ... * 2 * 1
     */
    public static double fact( int n )
    {
        // could add error-checking to return NaN for negative numbers
        double result = 1.0; // since 0! = 1 and 1! = 1
        for (int i = 2; i <= n; i++) {
            result = result * i;
        }
        return result;
    }
    
    
    /**
     * Purpose: Calculate e^x (where e is the special number that is the base of
     * the natural logarithms) using power series x^0/0! + x^1/1! + ...
     * This is a smarter implementation using relationships between terms
     * 
     * @param dValue        value to find e^value
     * @param dPrecision    desired level of precision for calculation
     * @return              e^value to within the desired precision
     */
    public static double myImprovedExp( double dValue, double dPrecision )
    {
        double dResult = 1.0; // initial approximation - first term
        double dTerm = 1.0;
        int iCount = 0;
        
        if (dValue < 0) // for negative x, calculate 1/e^-x to avoid subtractions
        {
            return 1.0 / myImprovedExp( -dValue, dPrecision);
        }
        do {
            iCount++;
            // new term is just old term * x / iCount
            dTerm = dTerm * dValue / iCount;
            dResult += dTerm; // add the new term to get a better approximation
        } while (Math.abs(dTerm / dResult) > dPrecision);
        // use relative error (error is just last term, divide by result)
        
        return dResult;
    }

    
    /**
     * Purpose: Calculate the sine of an angle to a desired precision
     * with the angle expressed in radians
     * using power series x / 1! - x^3 / 3! + x^5 / 5! - ...
     * 
     * @param dValue        angle expressed in radians
     * @param dPrecision    desired level of precision for calculation
     * @return  sin(dValue) to within the desired precision
     */
    public static double mySin( double dValue, double dPrecision )
    {
        dValue = dValue % (2 * Math.PI); // leaves angle of only < 360 degrees
        
        double dResult = dValue; // initial approximation
        double dTerm = dValue;   // x^1 / 1! = x is the first term
        boolean bKeepGoing = true;
        double dSign = 1.0;
        int iCount = 1;
        
        while (bKeepGoing)
        {
            dSign *= -1.0; // terms alternate between + and -
            // each term is x^2 / ((count +1)(count+2)) bigger than previous
            dTerm = dTerm * dValue * dValue / ((iCount + 1) * (iCount + 2));
            iCount += 2;
            dResult += dSign * dTerm; // better approximation - add next term
            
            // could use amount of precision (dTerm) or relative precision
            if (Math.abs(dTerm / dResult) < dPrecision) // "close enough" 
            {
                bKeepGoing = false;
            }
        }
        
        return dResult;
    }

    
    /**
     * Purpose: Find the square root of a given value to within the
     * desired precision. Uses method of bisection.
     * 
     * @param dValue        Value to find square root of
     * @param dPrecision    Level of precision sought for calculations
     * @return  Square root of value to within specified precision
     */
    public static double mySqrt( double dValue, double dPrecision )
    {
        double dResult = 0.0;
        if ( dValue < 0.0 )  // can't find square root of negative numbers
        {
            dResult = Double.NaN;
        }
        else if ( dValue > 0.0 ) // use bisection
        {
            // square root is between 1 and x
            double dUpper = dValue;
            double dLower = 1.0;
            double dGuess = dValue;
            boolean bKeepGoing = true;
            
            while (bKeepGoing)
            {
                dGuess = (dUpper + dLower) / 2.0; // new guess halfway between
                double dTest = dGuess * dGuess;
                
                if (dTest == dValue)
                { // if guess is exactly right, quit
                    bKeepGoing = false;
                }
                else if (dTest > dValue)
                { // if guess is too big, reset upper limit
                    dUpper = dGuess;
                }
                else
                { // guess must be too small, reset lower limit
                    dLower = dGuess;
                }
                
                // could use (dUpper - dLower) / dGuess for relative error
                //  or (dUpper - dLower) for amount of error
                if ((dUpper - dLower) < dPrecision) // "close enough"
                {
                    bKeepGoing = false;
                }
            }
            dResult = dGuess;
        }
        
        return dResult;
    }
}
